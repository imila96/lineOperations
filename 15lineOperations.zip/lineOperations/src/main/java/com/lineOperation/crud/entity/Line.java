package com.lineOperation.crud.entity;


import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Entity
@Table(name = "line_entries")
@Data
@NoArgsConstructor
public class Line {

    @Id
    private long id;

    private String shiftBteamLeader;

    private String shiftAteamLeader;



}
